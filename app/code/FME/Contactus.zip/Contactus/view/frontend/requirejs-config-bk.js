 var config = {
map: {
    '*': {
        contactus:           'FME_Contactus/js/contactus',

    }
}};
