require([
"jquery"
], function($){
    $(document).ready(function() {
           alert("Hi, I am from custom_faq.js");
    });
});