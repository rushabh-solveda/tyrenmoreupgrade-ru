<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_PriceList
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\PriceList\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public $printPreQuery = false;

    public $printPostQuery = false;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_resource;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\CartFactory $cart
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\CartFactory $cart,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Webkul\PriceList\Model\ItemsFactory $items
    ) {
        $this->_request = $context->getRequest();
        $this->_resource = $resource;
        $this->_customerSession = $customerSession;
        $this->_cart = $cart;
        $this->_timezone = $timezone;
        $this->_items = $items;
        parent::__construct($context);
    }

    public function getPrice($product, $price)
    {
        $ruleDetails = $this->getPreAppliedRuleDetails($product);
        return $this->getFinalPrice($ruleDetails, $price);
    }

    /**
     * Get Original Price of Product
     * created to get original prie in cart
     */
    public function getOriginalPrice($product, $price, $ruleDetails)
    {
        if ($ruleDetails['rule_id'] > 0) {
            $amount = $ruleDetails['amount'];
            if ($ruleDetails['fixed']) {
                if ($ruleDetails['discount']) {
                    $price = $price + $amount;
                } else {
                    $price = $price - $amount;
                }
            } else {
                if ($ruleDetails['discount']) {
                    $price = ($price * 100)/(100 - $amount);
                } else {
                    $price = ($price * 100)/(100 + $amount);
                }
            }
        }
        return $price;
    }

    public function getPostAppliedRuleDetails($product, $qty, $total, $exclude = false)
    {
        $details = ['amount' => 0, 'rule_id' => 0, "discount" => true, 'fixed' => true];
        $customerId = 0;
        $customerGroupId = 0;
        if ($this->_customerSession->isLoggedIn()) {
            $customer = $this->_customerSession->getCustomer();
            $customerId = $customer->getId();
            $customerGroupId = $customer->getGroupId();
        }
        $categoyIds = $product->getCategoryIds();
        $collection = $this->_items->create()->getCollection();
        $collection = $this->joinRules($collection);
        $collection = $this->joinAssignedRules($collection);
        $collection = $this->joinUser($collection);
        $collection = $this->joinPriceList($collection);
        $today = $this->_timezone->date()->format('Y-m-d');
        $sql = '(';
        if ($exclude) {
            $sql .= '(main_table.entity_type= 3 and main_table.entity_value <= '.$qty.')';
            $sql .= ' or (main_table.entity_type= 4 and main_table.entity_value <= '.$total.')';
            $sql .= ')';
            $sql .= ' and (';
            $sql .= '(pricelist.start_date <="'.$today.'" and pricelist.end_date >="'.$today.'") and';
            $sql .= ' rule.status = 1 and pricelist.status = 1';
            $sql .= ' and rule.is_combination=0';
            $sql .= ' and ((user.type = 1 and user.user_id = '.$customerId.') or (user.type = 2 and user.user_id = '.$customerGroupId.'))';
            $sql .= ')';
        } else {
            $sql .= '(main_table.entity_type= 1 and main_table.entity_value = '.$product->getId().')';
            foreach ($categoyIds as $categoyId) {
                $sql .= ' or (main_table.entity_type= 2 and main_table.entity_value = '.$categoyId.')';
            }
            $sql .= ' or (main_table.entity_type= 3 and main_table.entity_value <= '.$qty.')';
            $sql .= ' or (main_table.entity_type= 4 and main_table.entity_value <= '.$total.')';
            $sql .= ')';
            $sql .= ' and (';
            $sql .= '(pricelist.start_date <="'.$today.'" and pricelist.end_date >="'.$today.'") and';
            $sql .= ' rule.status = 1 and pricelist.status = 1';
            $sql .= ' and rule.is_combination=0';
            $sql .= ' and ((user.type = 1 and user.user_id = '.$customerId.') or (user.type = 2 and user.user_id = '.$customerGroupId.'))';
            $sql .= ')';
        }
        $collection->getSelect()->where($sql);
        $collection->getSelect()->order('pricelist.priority', 'ASC');
        $collection->getSelect()->order('rule.priority', 'ASC');
        $collection->getSelect()->order('rule.id', 'ASC');
        $collection->getSelect()->order('main_table.id', 'ASC');

        $collection->getSelect()->limit(1);
        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $item->getPricelistPriority();
                $calculationType = $item->getCalculationType();
                $priceType = $item->getPriceType();
                $amount = $item->getAmount();
                if ($priceType == 2) { // percent amount
                    $details['fixed'] = false;
                }
                if ($calculationType == 1) { // increase price
                    $details['discount'] = false;
                }
                $details['rule_id'] = $item->getRuleId();
                $details['amount'] = $amount;
                $details['rule_priority'] = $item->getRulePriority();
                $details['pricelist_priority'] = $item->getPricelistPriority();
            }
        }
        return $details;
    }

    public function joinRules($collection)
    {
        $joinTable = $this->_resource->getTableName('wk_pricelist_rule');
        $sql = 'main_table.parent_id = rule.id';
        $fields = ['calculation_type', 'price_type', 'amount', 'status', 'priority as rule_priority'];
        $collection->getSelect()->join($joinTable.' as rule', $sql, $fields);
        $collection->addFilterToMap('id', 'main_table.id');
        return $collection;
    }

    public function joinAssignedRules($collection)
    {
        $joinTable = $this->_resource->getTableName('wk_pricelist_assigned_rule');
        $sql = 'main_table.parent_id = assigned_rule.rule_id';
        $fields = ['pricelist_id', 'rule_id'];
        $collection->getSelect()->join($joinTable.' as assigned_rule', $sql, $fields);
        return $collection;
    }

    public function joinUser($collection)
    {
        $joinTable = $this->_resource->getTableName('wk_pricelist_user_details');
        $sql = 'assigned_rule.pricelist_id = user.pricelist_id';
        $fields = ['pricelist_id', 'user_id', 'type'];
        $collection->getSelect()->join($joinTable.' as user', $sql, $fields);
        return $collection;
    }

    public function joinPriceList($collection)
    {
        $joinTable = $this->_resource->getTableName('wk_pricelist_list');
        $sql = 'pricelist.id = user.pricelist_id';
        $fields = ['priority as pricelist_priority', 'status'];
        $collection->getSelect()->join($joinTable.' as pricelist', $sql, $fields);
        return $collection;
    }

    public function getProductFilterQuery($product)
    {
        $sql = '(main_table.entity_type= 1 and main_table.entity_value = '.$product->getId().')';
        return $sql;
    }

    public function getCategoryFilterQuery($product)
    {
        $categoyIds = $product->getCategoryIds();
        $sql = [];
        foreach ($categoyIds as $categoyId) {
            $sql[] = '(main_table.entity_type= 2 and main_table.entity_value = '.$categoyId.")";
        }
        $sql = implode(" or ", $sql);
        return $sql;
    }

    public function getStatusFilterQuery()
    {
        $sql = ' rule.status = 1 and pricelist.status = 1';
        return $sql;
    }

    public function getPreAppliedRuleDetails($product, $excludeCartRule = false)
    {
        $total = (float) $product->getData("price");
        $details = ['amount' => 0, 'rule_id' => 0, "discount" => true, 'fixed' => true];
        $customerId = 0;
        $customerGroupId = 0;
        if ($this->_customerSession->isLoggedIn()) {
            $customer = $this->_customerSession->getCustomer();
            $customerId = $customer->getId();
            $customerGroupId = $customer->getGroupId();
        }
        $categoyIds = $product->getCategoryIds();
        $collection = $this->_items->create()->getCollection();
        $collection = $this->joinRules($collection);
        $collection = $this->joinAssignedRules($collection);
        $collection = $this->joinUser($collection);
        $collection = $this->joinPriceList($collection);

        $today = $this->_timezone->date()->format('Y-m-d');
        $sql = "(";
        $sql .= '(main_table.entity_type= 1 and main_table.entity_value = '.$product->getId().")";
        foreach ($categoyIds as $categoyId) {
            $sql .= ' or (main_table.entity_type= 2 and main_table.entity_value = '.$categoyId.")";
        }
        if (!$excludeCartRule) {
            $sql .= ' or (main_table.entity_type= 3 and main_table.entity_value = 1)';
            $sql .= ' or (main_table.entity_type= 4 and main_table.entity_value <= '.$total.')';
        }
        $sql .= ")";
        $sql .= ' and (';
        $sql .= '(pricelist.start_date <="'.$today.'" and pricelist.end_date >="'.$today.'") and';
        $sql .= ' rule.status = 1 and pricelist.status = 1';
        $sql .= ' and rule.is_combination=0';
        $sql .= ' and ((user.type = 1 and user.user_id = '.$customerId.') or (user.type = 2 and user.user_id = '.$customerGroupId.'))';
        $sql .= ')';
        $collection->getSelect()->where($sql);

        $collection->getSelect()->order('pricelist.priority', 'ASC');
        $collection->getSelect()->order('rule.priority', 'ASC');
        $collection->getSelect()->order('rule.id', 'ASC');
        $collection->getSelect()->order('main_table.id', 'ASC');
        $collection->getSelect()->group('main_table.parent_id');
        $collection->getSelect()->limit(1);
        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $item->getPricelistPriority();
                $calculationType = $item->getCalculationType();
                $priceType = $item->getPriceType();
                $amount = $item->getAmount();
                if ($priceType == 2) {
                    $details['fixed'] = false;
                }
                if ($calculationType == 1) {
                    $details['discount'] = false;
                }
                $details['rule_id'] = $item->getRuleId();
                $details['amount'] = $amount;
                $details['rule_priority'] = $item->getRulePriority();
                $details['pricelist_priority'] = $item->getPricelistPriority();
            }
        }
        return $details;
    }

    public function getCalculationTypeOptions()
    {
        $options = [];
        $options[1] = __('Increase Price');
        $options[2] = __('Decrease Price');
        return $options;
    }

    public function getPriceTypeOptions()
    {
        $options = [];
        $options[1] = __('Fixed Price');
        $options[2] = __('Percent Price');
        return $options;
    }

    public function getStatusOptions()
    {
        $options = [];
        $options[1] = __('Active');
        $options[2] = __('Deactive');
        return $options;
    }

    public function getObjectManager()
    {
        return \Magento\Framework\App\ObjectManager::getInstance();
    }

    public function getCustomOptionPrice($item, $price)
    {
        $customOptionPrice = 0;
        $product = $item->getProduct();
        $customOptions = $item->getProduct()
                            ->getTypeInstance(true)
                            ->getOrderOptions($item->getProduct());
        $infoBuyRequest = $customOptions['info_buyRequest'];
        try {
            if (array_key_exists("options", $infoBuyRequest)) {
                $selectedOptions = $infoBuyRequest['options'];
                foreach ($product->getOptions() as $option) {
                    $optionId = $option->getOptionId();
                    if (array_key_exists($optionId, $selectedOptions)) {
                        if (trim($selectedOptions[$optionId]) == "") {
                            continue;
                        }
                        $optionType = $option->getType();
                        $singleValueOptions = ['drop_down', 'radio'];
                        $multiValueOptions = ['checkbox', 'multiple'];
                        if (in_array($optionType, $singleValueOptions)) {
                            $values = $option->getValues();
                            foreach ($values as $value) {
                                if ($value->getOptionTypeId() == $selectedOptions[$optionId]) {
                                    $priceType = $value->getPriceType();
                                    $optionPrice = $value->getPrice();
                                    if ($priceType != "fixed") {
                                        $optionPrice = ($price*$optionPrice)/100;
                                    }
                                    $customOptionPrice += $optionPrice;
                                }
                            }
                        } elseif (in_array($optionType, $multiValueOptions)) {
                            $values = $option->getValues();
                            foreach ($values as $value) {
                                if (in_array($value->getOptionTypeId(), $selectedOptions[$optionId])) {
                                    $priceType = $value->getPriceType();
                                    $optionPrice = $value->getPrice();
                                    if ($priceType != "fixed") {
                                        $optionPrice = ($price*$optionPrice)/100;
                                    }
                                    $customOptionPrice += $optionPrice;
                                }
                            }
                        } else {
                            $priceType = $option->getPriceType();
                            $optionPrice = $option->getPrice();
                            if ($priceType != "fixed") {
                                $optionPrice = ($price*$optionPrice)/100;
                            }
                            $customOptionPrice += $optionPrice;
                        }
                    }
                }
            }
        } catch (\Exception $e) {
        }
        return $customOptionPrice;
    }

    public function processItemPrice($item, $parentItem = false, $useParent = false, $excludeCartRule = false)
    {
        $result = ['updated' => false];
        try {
            $preRuleApplied = false;
            $postRuleApplied = false;
            $cartItemPrice = $this->getOriginalPriceByItem($item);
            $originalCartItemPrice = $cartItemPrice;
            $product = $item->getProduct();
            $qty = $item->getQty();
            if ($useParent) {
                $qty = $parentItem->getQty();
            }
            $price = $product->getData("price");
            $originalCustomOptionPrice = $this->getCustomOptionPrice($item, $price);
            $preAppliedDetails = $this->getPreAppliedRuleDetails($product, $excludeCartRule);
            if ($preAppliedDetails['rule_id'] > 0) {
                $priceAfterRule = $this->getFinalPrice($preAppliedDetails, $price);
                $customOptionPrice = $this->getCustomOptionPrice($item, $priceAfterRule);
                if ($preAppliedDetails['discount']) {
                    $differnce = $originalCustomOptionPrice - $customOptionPrice;
                    $differnce += $price - $priceAfterRule;
                    $originalCartItemPrice = $cartItemPrice + $differnce;
                } else {
                    $differnce = $customOptionPrice - $originalCustomOptionPrice;
                    $differnce += $priceAfterRule - $price;
                    $originalCartItemPrice = $cartItemPrice - $differnce;
                }
                $preRuleApplied = true;
            }
            $total = $originalCartItemPrice * $qty;
            $postAppliedDetails = $this->getPostAppliedRuleDetails($product, $qty, $total);
            if ($postAppliedDetails['rule_id'] > 0) {
                if ($preRuleApplied) {
                    if ($postAppliedDetails['rule_id'] != $preAppliedDetails['rule_id']) {
                        if ($postAppliedDetails['pricelist_priority'] <= $preAppliedDetails['pricelist_priority']) {
                            if ($postAppliedDetails['rule_priority'] < $preAppliedDetails['rule_priority']) {
                                $postRuleApplied = true;
                            }
                        }
                    }
                } else {
                    $postRuleApplied = true;
                }
            }
            if ($postRuleApplied) {
                if ($preRuleApplied) { // need recalculation
                    if ($postRuleApplied['discount']) {
                        $differnce = $originalCustomOptionPrice - $customOptionPrice;
                        $differnce += $price - $priceAfterRule;
                        $originalCartItemPrice = $cartItemPrice + $differnce;
                    } else {
                        $differnce = $customOptionPrice - $originalCustomOptionPrice;
                        $differnce += $priceAfterRule - $price;
                        $originalCartItemPrice = $cartItemPrice - $differnce;
                    }
                    $extraPrice = $originalCartItemPrice - $originalCustomOptionPrice - $price;
                } else {
                    $extraPrice = $originalCartItemPrice - $originalCustomOptionPrice - $price;
                }
                $finalPrice = $this->getFinalPrice($postAppliedDetails, $price);
                $finalCustomOptionPrice = $this->getCustomOptionPrice($item, $finalPrice);
                $totalPrice = $extraPrice + $finalPrice + $finalCustomOptionPrice;
                $item->setCustomPrice($totalPrice);
                $item->setOriginalCustomPrice($totalPrice);
                $item->setRowTotal($item->getQty()*$totalPrice);
                $item->getProduct()->setIsSuperMode(true);
                $item->save();
                $result['updated'] = true;
                $result['price'] = $totalPrice;
                return $result;
            }
            $result['price'] = $cartItemPrice;
        } catch (\Exception $e) {

        }
        return $result;
        
    }

    /**
     * Collect Totals
     *
     * @param object $quote
     */
    public function collectTotals($quote)
    {
        $itemDetails = [];
        $configItemIds = [];
        $bundleItemIds = [];
        $hasBundleProduct = false;
        $hasConfigProduct = false;
        foreach ($quote->getAllItems() as $item) {
            $this->refreshProductPrice($item);
            if ($item->getParentItem()) {
                $itemDetails[$item->getParentItem()->getId()][] = $item;
                continue;
            }
            if ($item->getProduct()->getTypeId() == "configurable") {
                $configItemIds[] = $item->getId();
                $hasConfigProduct = true;
                continue;
            }
            if ($item->getProduct()->getTypeId() == "bundle") {
                $bundleItemIds[] = $item->getId();
                $hasBundleProduct = true;
                continue;
            }
            $this->processItemPrice($item);
        }
        if ($hasBundleProduct) {
            $this->updateBundleItemPrice($bundleItemIds, $itemDetails);
        }
        if ($hasConfigProduct) {
            $this->updateConfigItemPrice($configItemIds, $itemDetails);
        }
    }

    public function updateConfigItemPrice($configItemIds, $itemDetails)
    {
        try {
            foreach ($configItemIds as $itemId) {
                foreach ($itemDetails[$itemId] as $item) {
                    $parentItem = $item->getParentItem();
                    $result = $this->processItemPrice($item, $parentItem, true);
                    if ($result['updated']) {
                        $price = $result['price'];
                        $parentItem->setOriginalCustomPrice($price);
                        $parentItem->setRowTotal($item->getQty()*$price);
                        $parentItem->getProduct()->setIsSuperMode(true);
                        $parentItem->save();
                    }
                }
            }
        } catch (\Exception $e) {
        }
    }

    public function updateBundleItemPrice($bundleItemIds, $itemDetails)
    {
        try {
            foreach ($bundleItemIds as $itemId) {
                $updated = false;
                $totalPrice = 0;
                foreach ($itemDetails[$itemId] as $item) {
                    $parentItem = $item->getParentItem();
                    $result = $this->processItemPrice($item, $parentItem, false, true);
                    if ($result['updated']) {
                        $updated = true;
                    }
                    $totalPrice += $result['price'];
                }
                if ($updated) {
                    $parentItem->setOriginalCustomPrice($totalPrice);
                    $parentItem->setRowTotal($item->getQty()*$totalPrice);
                    $parentItem->getProduct()->setIsSuperMode(true);
                    $parentItem->save();
                }
            }
        } catch (\Exception $e) {
        }
    }

    public function getOriginalPriceByItem($item)
    {
        $price = 0;
        $product = $item->getProduct();
        if ($item->getParentItem()) {
            $price = $item->getParentItem()
                        ->getProduct()
                        ->getPriceModel()
                        ->getChildFinalPrice(
                            $item->getParentItem()->getProduct(),
                            $item->getParentItem()->getQty(),
                            $product,
                            $item->getQty()
                        );
        } elseif (!$item->getParentItem()) {
            $price = $product->getFinalPrice($item->getQty());
        }
        return $price;
    }

    /**
     * Refresh Product Price In Cart
     *
     * @param object $item
     */
    public function refreshProductPrice($item)
    {
        try {
            $item->setCustomPrice(null);
            $item->setOriginalCustomPrice(null);
            $item->getProduct()->setIsSuperMode(true);
            $item->save();
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Save Quote Item Updates
     *
     * @return string
     */
    public function checkStatus()
    {
        $this->_cart->create()->save();
    }

    public function getFinalPrice($ruleDetails, $price)
    {
        if ($ruleDetails['rule_id'] > 0) {
            $amount = $ruleDetails['amount'];
            if (!$ruleDetails['fixed']) {
                $amount = ($price* $amount) / 100;
            }
            if ($ruleDetails['discount']) {
                $price -= $amount;
            } else {
                $price += $amount;
            }
        }
        return $price;
    }

    public function getDefaultPrice($ruleDetails, $price)
    {
        if ($ruleDetails['rule_id'] > 0) {
            $amount = $ruleDetails['amount'];
            if ($ruleDetails['fixed']) {
                if ($ruleDetails['discount']) {
                    $price = $price + $amount;
                } else {
                    $price = $price - $amount;
                }
            } else {
                if ($ruleDetails['discount']) {
                    $price = ($price * 100)/(100 - $amount);
                } else {
                    $price = ($price * 100)/(100 + $amount);
                }
            }
        }
        return $price;
    }

    public function printPostQuery()
    {
        return $this->printPostQuery;
    }

    public function printPreQuery()
    {
        return $this->printPreQuery;
    }
}
