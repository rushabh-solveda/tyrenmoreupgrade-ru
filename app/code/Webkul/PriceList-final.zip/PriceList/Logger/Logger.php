<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_PriceList
 * @author     Webkul
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\PriceList\Logger;
 
class Logger extends \Monolog\Logger
{
}
